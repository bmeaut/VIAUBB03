export type PegType = 'code' | 'key';
